var texts = “I am your JavaScript Program”;

console.log(texts);


